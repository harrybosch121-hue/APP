import React, { createContext, useContext, useState, ReactNode } from "react";
import marbleTile from "@/assets/marble-tile.jpeg";

export type TileType = "Gloss" | "Matt" | "MattyGloss";

export interface Tile {
  id: string;
  name: string;
  type: TileType;
  quantity: number;
  location: string;
  image: string;
}

export interface AuditEntry {
  id: string;
  staffName: string;
  action: "Added" | "Removed";
  tileName: string;
  quantity: number;
  timestamp: Date;
}

interface InventoryContextType {
  tiles: Tile[];
  logs: AuditEntry[];
  addTile: (tile: Omit<Tile, "id">) => void;
  updateStock: (id: string, quantity: number) => void;
  removeStock: (id: string, quantity: number) => void;
  getTile: (id: string) => Tile | undefined;
}

const InventoryContext = createContext<InventoryContextType | undefined>(undefined);

const demoTiles: Tile[] = [
  { id: "1", name: "Carrara White Marble", type: "Gloss", quantity: 120, location: "Godown 1", image: marbleTile },
  { id: "2", name: "Statuario Veined", type: "Matt", quantity: 85, location: "Godown 2", image: marbleTile },
  { id: "3", name: "Calacatta Gold", type: "Gloss", quantity: 45, location: "Godown 1", image: marbleTile },
  { id: "4", name: "Emperador Dark", type: "MattyGloss", quantity: 200, location: "Godown 3", image: marbleTile },
  { id: "5", name: "Crema Marfil Beige", type: "Matt", quantity: 60, location: "Godown 2", image: marbleTile },
];

const demoLogs: AuditEntry[] = [
  { id: "l1", staffName: "Rajesh K.", action: "Added", tileName: "Carrara White Marble", quantity: 50, timestamp: new Date(Date.now() - 3600000) },
  { id: "l2", staffName: "Amit S.", action: "Removed", tileName: "Emperador Dark", quantity: 10, timestamp: new Date(Date.now() - 7200000) },
  { id: "l3", staffName: "Priya M.", action: "Added", tileName: "Calacatta Gold", quantity: 25, timestamp: new Date(Date.now() - 86400000) },
];

export function InventoryProvider({ children }: { children: ReactNode }) {
  const [tiles, setTiles] = useState<Tile[]>(demoTiles);
  const [logs, setLogs] = useState<AuditEntry[]>(demoLogs);

  const addLog = (action: "Added" | "Removed", tileName: string, quantity: number) => {
    setLogs((prev) => [
      { id: crypto.randomUUID(), staffName: "Staff", action, tileName, quantity, timestamp: new Date() },
      ...prev,
    ]);
  };

  const addTile = (tile: Omit<Tile, "id">) => {
    const newTile = { ...tile, id: crypto.randomUUID() };
    setTiles((prev) => [newTile, ...prev]);
    addLog("Added", tile.name, tile.quantity);
  };

  const updateStock = (id: string, quantity: number) => {
    setTiles((prev) => prev.map((t) => (t.id === id ? { ...t, quantity } : t)));
    const tile = tiles.find((t) => t.id === id);
    if (tile) addLog("Added", tile.name, quantity - tile.quantity);
  };

  const removeStock = (id: string, quantity: number) => {
    setTiles((prev) => prev.map((t) => (t.id === id ? { ...t, quantity: Math.max(0, t.quantity - quantity) } : t)));
    const tile = tiles.find((t) => t.id === id);
    if (tile) addLog("Removed", tile.name, quantity);
  };

  const getTile = (id: string) => tiles.find((t) => t.id === id);

  return (
    <InventoryContext.Provider value={{ tiles, logs, addTile, updateStock, removeStock, getTile }}>
      {children}
    </InventoryContext.Provider>
  );
}

export function useInventory() {
  const ctx = useContext(InventoryContext);
  if (!ctx) throw new Error("useInventory must be used within InventoryProvider");
  return ctx;
}
