import { useState } from "react";
import { Minus, Plus, Upload, Image as ImageIcon } from "lucide-react";
import { useInventory, TileType } from "@/context/InventoryContext";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import marbleTile from "@/assets/marble-tile.jpeg";
import { toast } from "sonner";

export default function StockScreen() {
  const { addTile } = useInventory();
  const [name, setName] = useState("");
  const [quantity, setQuantity] = useState(1);
  const [type, setType] = useState<TileType>("Gloss");
  const [location, setLocation] = useState("");
  const [preview, setPreview] = useState<string | null>(null);

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => setPreview(reader.result as string);
      reader.readAsDataURL(file);
    }
  };

  const handleSave = () => {
    if (!name.trim() || !location.trim()) {
      toast.error("Please fill in all fields");
      return;
    }
    addTile({ name, quantity, type, location, image: preview || marbleTile });
    toast.success(`${name} added successfully`);
    setName("");
    setQuantity(1);
    setLocation("");
    setPreview(null);
  };

  return (
    <div className="min-h-screen premium-bg marble-noise pb-20 pt-4">
      <div className="px-5">
        <h2 className="font-display text-2xl font-light text-foreground mb-6">Add Stock</h2>

        <div className="space-y-5">
          {/* Tile Name */}
          <div>
            <label className="font-body text-xs font-medium text-muted-foreground uppercase tracking-wider mb-1.5 block">
              Tile Name
            </label>
            <input
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g. Carrara White Marble"
              className="w-full px-4 py-3 rounded-xl bg-card border border-border text-foreground placeholder:text-muted-foreground font-body text-sm focus:outline-none focus:ring-2 focus:ring-primary/30 transition-shadow"
            />
          </div>

          {/* Quantity Stepper */}
          <div>
            <label className="font-body text-xs font-medium text-muted-foreground uppercase tracking-wider mb-1.5 block">
              Quantity
            </label>
            <div className="flex items-center gap-4">
              <button
                onClick={() => setQuantity((q) => Math.max(1, q - 1))}
                className="w-10 h-10 rounded-full bg-card border border-border flex items-center justify-center btn-press text-foreground"
              >
                <Minus className="w-4 h-4" />
              </button>
              <input
                type="number"
                value={quantity}
                onChange={(e) => setQuantity(Math.max(1, parseInt(e.target.value) || 1))}
                className="w-20 text-center py-2 rounded-xl bg-card border border-border text-foreground font-body text-lg font-semibold focus:outline-none focus:ring-2 focus:ring-primary/30"
              />
              <button
                onClick={() => setQuantity((q) => q + 1)}
                className="w-10 h-10 rounded-full bg-primary text-primary-foreground flex items-center justify-center btn-press shadow-md"
              >
                <Plus className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Type Dropdown */}
          <div>
            <label className="font-body text-xs font-medium text-muted-foreground uppercase tracking-wider mb-1.5 block">
              Type
            </label>
            <Select value={type} onValueChange={(v) => setType(v as TileType)}>
              <SelectTrigger className="rounded-xl bg-card border-border h-12">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="Gloss">Gloss</SelectItem>
                <SelectItem value="Matt">Matt</SelectItem>
                <SelectItem value="MattyGloss">MattyGloss</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Location */}
          <div>
            <label className="font-body text-xs font-medium text-muted-foreground uppercase tracking-wider mb-1.5 block">
              Location (Godown)
            </label>
            <input
              value={location}
              onChange={(e) => setLocation(e.target.value)}
              placeholder="e.g. Godown 1"
              className="w-full px-4 py-3 rounded-xl bg-card border border-border text-foreground placeholder:text-muted-foreground font-body text-sm focus:outline-none focus:ring-2 focus:ring-primary/30 transition-shadow"
            />
          </div>

          {/* Image Upload */}
          <div>
            <label className="font-body text-xs font-medium text-muted-foreground uppercase tracking-wider mb-1.5 block">
              Tile Image
            </label>
            <label className="flex items-center gap-3 p-4 rounded-xl bg-card border border-dashed border-border cursor-pointer hover:border-primary/40 transition-colors">
              <Upload className="w-5 h-5 text-muted-foreground" />
              <span className="font-body text-sm text-muted-foreground">Upload image</span>
              <input type="file" accept="image/*" className="hidden" onChange={handleImageUpload} />
            </label>
            {preview && (
              <div className="mt-3 relative">
                <img src={preview} alt="Preview" className="w-full h-40 object-cover rounded-xl" />
              </div>
            )}
          </div>

          {/* Save Button */}
          <Button
            onClick={handleSave}
            className="w-full h-13 rounded-xl bg-primary text-primary-foreground font-body font-semibold text-sm shadow-lg btn-press hover:shadow-xl transition-shadow mt-4"
          >
            Save Tile
          </Button>
        </div>
      </div>
    </div>
  );
}
